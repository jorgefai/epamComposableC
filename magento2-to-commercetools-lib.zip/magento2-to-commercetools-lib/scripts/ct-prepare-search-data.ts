import * as fs from 'fs'

import { getProducts } from '../src/lib/commerce-tools/get-products'
import { getCategories } from '../src/lib/commerce-tools/get-categories'
import { commercetoolsProductsToProducts } from '../src/lib/commerce-tools/ct-products-to-searchable'

const OUTPUT_DIRECTORY = './dist'
const OUTPUT_FILE_NAME = `${OUTPUT_DIRECTORY}/converted_products.json`

export const prepareData = async () => {
  const [productsResult, categoriesResult] = await Promise.all([
    getProducts(500),
    getCategories(100),
  ])

  const convertedProducts = commercetoolsProductsToProducts(
    productsResult.results,
    categoriesResult.results
  )

  if (!fs.existsSync(OUTPUT_DIRECTORY)) {
    fs.mkdirSync(OUTPUT_DIRECTORY)
  }

  fs.writeFileSync(OUTPUT_FILE_NAME, JSON.stringify(convertedProducts, null, 2))

  console.log(`Products converted and saved to ${OUTPUT_FILE_NAME}`)
}

prepareData()
