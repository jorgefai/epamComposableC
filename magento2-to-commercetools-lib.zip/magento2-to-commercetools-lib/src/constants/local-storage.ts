export const NEXT_MAGENTO_CART = 'next-magento-cart'
