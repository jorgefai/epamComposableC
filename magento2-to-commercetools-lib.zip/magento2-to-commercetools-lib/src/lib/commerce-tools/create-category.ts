import 'dotenv/config'
import axios from 'axios'

import { createAuthHeaders } from './utils/create-auth-headers'
import { COMMERCE_TOOLS_PROJECT_URL } from '../../constants'

export async function createCategory(newCategoryData: any) {
  try {
    const authHeaders = await createAuthHeaders()
    const response = await axios.post(
      `${COMMERCE_TOOLS_PROJECT_URL}/categories`,
      newCategoryData,
      authHeaders
    )

    // Verificar que la respuesta contenga un ID válido
    if (response.data && response.data.id) {
      return response.data
    } else {
      console.error('Category creation response is missing an id:', response.data)
      return null
    }
  } catch (err: any) {
    if (err.response && err.response.data) {
      if (err.response.data.errors.find((el: any) => el.code === 'DuplicateField')) {
        return null
      }
      console.error('createCategory error:', err.response.data)
    } else {
      console.error('Unknown error occurred during category creation:', err)
    }
    throw err
  }
}
