import 'dotenv/config'
import axios from 'axios'

import { createAuthHeaders } from './utils/create-auth-headers'
import { COMMERCE_TOOLS_PROJECT_URL } from '../../constants'

export const createTaxCategory = async () => {
  const authHeaders = await createAuthHeaders()
  const response = await axios.post(
    `${COMMERCE_TOOLS_PROJECT_URL}/tax-categories`,
    {
      name : "tax-category",
      rates: [
        {
          name: "rate1",
          amount: 0.2,
          includedInPrice: true,
          country: "DE",
          id: "rat1",
          subRates: []
        },
        {
          name: "rate2",
          amount: 0.2,
          includedInPrice: true,
          country: "US",
          id: "rate2",
          subRates: []
        }
      ],
    },
    authHeaders
  );

  return response.data;
}
