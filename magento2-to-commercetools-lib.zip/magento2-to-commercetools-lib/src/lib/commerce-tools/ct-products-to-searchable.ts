/* eslint-disable @typescript-eslint/no-non-null-asserted-optional-chain */
/* eslint-disable @typescript-eslint/no-non-null-assertion */
const commerceCategoryToCategory = (draftCategory: any) => {
  return {
    id: draftCategory?.id,
    name: draftCategory?.name,
    ancestors: draftCategory?.ancestors,
    parent: draftCategory?.parent,
  }
}

const categoryToDeepTreeCategory = (draftCategory: any, categoriesMap: any) => {
  return {
    id: draftCategory?.id,
    name: draftCategory?.name,
    ancestors: draftCategory.ancestors?.map((category: any) => {
      return {
        id: categoriesMap[category.id!]?.id,
        name: categoriesMap[category.id!]?.name,
      }
    }),
    parent: {
      id: categoriesMap[draftCategory.parent?.id!]?.id,
      name: categoriesMap[draftCategory.parent?.id!]?.name,
    },
  }
}

const commerceAttributeToAttribute = (
  draftAttribute: any
): { [key: string]: any } => {
  return {
    [draftAttribute?.name?.toLowerCase()]: draftAttribute?.value,
  }
}

const commerceImageToImage = (draftImage: any) => {
  return {
    url: draftImage?.url,
    label: draftImage?.label,
  }
}

const commercePriceToPrice = (draftPrice: any) => {
  return {
    id: draftPrice?.id,
    value: {
      currencyCode: draftPrice?.value?.currencyCode,
      centAmount: draftPrice?.value?.centAmount,
    },
  }
}

const commerceProductVariantToProductVariant = (draftProductVariant: any) => {
  return {
    id: draftProductVariant?.id,
    sku: draftProductVariant?.sku,
    name: draftProductVariant?.name,
    slug: draftProductVariant?.slug,
    images: draftProductVariant?.images?.map(commerceImageToImage),
    prices: draftProductVariant?.prices?.map(commercePriceToPrice),
    attributes: draftProductVariant?.attributes?.map(
      commerceAttributeToAttribute
    ),
  }
}

const getCategoriesMap = (draftCategories: any) => {
  const categoriesMap: any = {}
  const categories = draftCategories.map((category: any) =>
    commerceCategoryToCategory(category)
  )

  categories.forEach((category: any) => {
    if (category.id) {
      categoriesMap[category.id] = category
    }
  })

  for (const categoryId in categoriesMap) {
    categoriesMap[categoryId] = categoryToDeepTreeCategory(
      categoriesMap[categoryId],
      categoriesMap
    )
  }

  return categoriesMap
}

const getCategories = (draftCategories: any, categoriesMap: any) => {
  const categories: any = []

  draftCategories.forEach(({ id }: any) => {
    categories.push(categoriesMap[id])
  })

  return categories
}

export const commercetoolsProductsToProducts = (
  draftProducts: any,
  draftCategories: any
) => {
  const categoryMap = getCategoriesMap(draftCategories)

  return draftProducts.map((draftProduct: any) => {
    return {
      id: draftProduct?.id,
      name: draftProduct?.masterData?.current?.name,
      description: draftProduct?.masterData?.current?.description,
      slug: draftProduct?.masterData?.current?.slug,
      categories: getCategories(
        draftProduct?.masterData?.current?.categories,
        categoryMap
      ),
      variants: draftProduct?.masterData?.current?.variants?.map(
        commerceProductVariantToProductVariant
      ),
      masterVariant: commerceProductVariantToProductVariant(
        draftProduct?.masterData?.current?.masterVariant
      ),
    }
  })
}
