import 'dotenv/config'
import axios from 'axios'

import { createAuthHeaders } from './utils/create-auth-headers'
import { COMMERCE_TOOLS_PROJECT_URL } from '../../constants'

export async function getTaxCategory() {
  try {
    const authHeaders = await createAuthHeaders()
    const response = await axios.get(
      `${COMMERCE_TOOLS_PROJECT_URL}/tax-categories`,
      authHeaders
    );

    return response.data.results[0];
  } catch (error: any) {
    console.error('getCategories error: ', error.response.data)
    throw error
  }
}
