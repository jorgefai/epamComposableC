import axios from 'axios';
import { MAGENTO_CATEGORIES_URL } from '../../constants';
import { Category } from '../../types/category';

export async function getActiveCategories(rootCategoryId = 2) {
  try {
    const res = await axios.get(MAGENTO_CATEGORIES_URL(rootCategoryId), {
      headers: {
        Authorization: `Bearer ${process.env.BEARER_TOKEN}`, // Usando el Bearer token de .env
      },
    });

    const dataRaw: Category = res.data;
    const activeCategories = dataRaw.children_data.filter((el: any) => {
      if (!el.is_active) return false;

      if (el.children_data.length) {
        el.children_data = el.children_data.filter((el: any) => el.is_active);
      }

      return true;
    });

    return activeCategories;
  } catch (error: unknown) {
    // Manejo de errores
    if (axios.isAxiosError(error)) {
      throw new Error(`Failed to fetch data: ${error.response?.data?.message || error.message}`);
    } else {
      throw new Error('An unknown error occurred');
    }
  }
}
