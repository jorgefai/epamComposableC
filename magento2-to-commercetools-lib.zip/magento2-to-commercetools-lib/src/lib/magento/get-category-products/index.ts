import axios from 'axios'
import qs from 'qs'

import { MagentoResultType } from '../../../types/magento-result'
import { ProductType } from '../../../types/product'
import { addSizesColorsToProducts } from './add-sizes-colors-to-products'
import { getConfigurableAttrIds } from './get-configurable-attr-ids'
import { createProductAttributesMap } from './create-product-attributes-map'
import { getProductSearchCriteria } from './get-product-search-criteria'
import { MAGENTO_PRODUCTS_URL } from '../../../constants/magento'

const BEARER_TOKEN = process.env.BEARER_TOKEN // Asegúrate de tener este token en tu archivo .env

export const MAGENTO_PRODUCTS_SEARCH_URL = new URL(MAGENTO_PRODUCTS_URL)

export async function getCategoryProducts(
  id: number | string,
  configurableOnly = true
) {
  const defaultProducts = {
    items: [],
    total_count: 0,
    search_criteria: {
      page_size: 0,
      current_page: 0,
    },
  } as unknown as MagentoResultType<ProductType>

  if (!id) return defaultProducts

  const searchCriteria = getProductSearchCriteria(id, configurableOnly)
  MAGENTO_PRODUCTS_SEARCH_URL.search = qs.stringify(searchCriteria)

  try {
    const response = await axios.get(MAGENTO_PRODUCTS_SEARCH_URL.toString(), {
      headers: {
        Authorization: `Bearer ${BEARER_TOKEN}` // Añadimos el Bearer Token en los headers
      }
    })

    const dataRaw = response.data
    const prodAttrIds = getConfigurableAttrIds(dataRaw.items)
    const attrsMap = await createProductAttributesMap(prodAttrIds)
    const mapped = addSizesColorsToProducts(dataRaw.items, attrsMap)

    return {
      items: mapped,
      total_count: dataRaw.total_count,
      search_criteria: dataRaw.search_criteria,
    }
  } catch (error) {
    console.error('Error fetching category products:', error)
    return {
      items: [],
      total_count: 0,
      search_criteria: {},
    } as unknown as MagentoResultType<ProductType>
  }
}
