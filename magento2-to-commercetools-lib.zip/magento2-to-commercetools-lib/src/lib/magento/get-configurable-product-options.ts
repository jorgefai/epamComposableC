import axios, { AxiosResponse } from 'axios'
import { ProductType } from '../../types/product'
import { MAGENTO_CONFIGURABLE_PRODUCT_OPTIONS_URL } from '../../constants'

const BEARER_TOKEN = process.env.BEARER_TOKEN // Asegúrate de tener este token en tu archivo .env

export async function getConfigurableProductOptions(
  sku: string,
  cpoId: number
) {
  if (!sku || !cpoId) return {}

  try {
    const response: AxiosResponse = await axios.get<ProductType>(
      MAGENTO_CONFIGURABLE_PRODUCT_OPTIONS_URL(sku, cpoId),
      {
        headers: {
          Authorization: `Bearer ${BEARER_TOKEN}` // Se agrega el token en los headers
        }
      }
    )
    return response.data
  } catch (error) {
    console.error('Error fetching configurable product options:', error)
    return {} // Devuelve un objeto vacío en caso de error
  }
}
