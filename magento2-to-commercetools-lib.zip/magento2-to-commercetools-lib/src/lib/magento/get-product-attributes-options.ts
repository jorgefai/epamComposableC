import axios from 'axios'
import { MAGENTO_PRODUCT_ATTRIBUTE_OPTIONS_URL } from '../../constants'

const BEARER_TOKEN = process.env.BEARER_TOKEN // Asegúrate de tener este token en tu archivo .env

export async function getProductAttributeOptions(attrId: string | number) {
  if (!attrId) return []

  try {
    const response = await axios.get(MAGENTO_PRODUCT_ATTRIBUTE_OPTIONS_URL(attrId), {
      headers: {
        Authorization: `Bearer ${BEARER_TOKEN}`
      }
    })

    const dataRaw = response.data
    return dataRaw
  } catch (error) {
    console.error('Error fetching product attribute options:', error)
    return []
  }
}
