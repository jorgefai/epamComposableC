import axios from 'axios'
import { ProductType } from '../../types/product'
import { getConfigurableAttrIds } from './get-category-products/get-configurable-attr-ids'
import { createProductAttributesMap } from './get-category-products/create-product-attributes-map'
import { addSizesColorsToProducts } from './get-category-products/add-sizes-colors-to-products'
import { MAGENTO_PRODUCT_BY_SKU_URL } from '../../constants/magento'

const BEARER_TOKEN = process.env.BEARER_TOKEN // Asegúrate de tener este token en tu archivo .env

export async function getProduct(sku: string): Promise<ProductType | null> {
  if (!sku) return null

  try {
    const response = await axios.get(MAGENTO_PRODUCT_BY_SKU_URL(sku), {
      headers: {
        Authorization: `Bearer ${BEARER_TOKEN}`
      }
    })

    const data = response.data

    if (data.type_id !== 'configurable') return data

    const prodAttrIds = getConfigurableAttrIds([data])
    const attrsMap = await createProductAttributesMap(prodAttrIds)
    const [mapped] = addSizesColorsToProducts([data], attrsMap)

    return mapped
  } catch (error) {
    console.error('Error fetching product by SKU:', error)
    return null
  }
}
