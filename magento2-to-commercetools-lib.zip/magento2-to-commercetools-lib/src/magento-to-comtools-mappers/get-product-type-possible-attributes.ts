import axios from 'axios'
import qs from 'qs'

import { MagentoResultType } from '../types/magento-result'
import { ProductType } from '../types/product'

import { createProductAttributesMap } from '../lib/magento/get-category-products/create-product-attributes-map'
import { getConfigurableAttrIds } from '../lib/magento/get-category-products/get-configurable-attr-ids'
import { getProductSearchCriteria } from '../lib/magento/get-category-products/get-product-search-criteria'
import { MAGENTO_PRODUCTS_URL } from '../constants/magento'

const BEARER_TOKEN = process.env.BEARER_TOKEN // Asegúrate de tener este token en tu archivo .env

export const MAGENTO_PRODUCTS_SEARCH_URL = new URL(MAGENTO_PRODUCTS_URL)

export async function getProductTypePossibleAttributes(leafCategory: any) {
  const productCategoryId = leafCategory.id
  const searchCriteria = getProductSearchCriteria(productCategoryId)
  MAGENTO_PRODUCTS_SEARCH_URL.search = qs.stringify(searchCriteria)

  try {
    const response = await axios.get<MagentoResultType<ProductType>>(MAGENTO_PRODUCTS_SEARCH_URL.toString(), {
      headers: {
        Authorization: `Bearer ${BEARER_TOKEN}` // Añadimos el Bearer Token en los headers
      }
    })

    const dataRaw = response.data
    const prodAttrIds = getConfigurableAttrIds(dataRaw.items)
    const attrsMap = await createProductAttributesMap(prodAttrIds)
    const newAttrMap: any = {}

    Object.keys(attrsMap).forEach((key) => {
      prodAttrIds.forEach((attr) => {
        if (key === attr.attribute_id) {
          newAttrMap[attr.label] = attrsMap[key]
        }
      })
    })

    return newAttrMap
  } catch (error) {
    console.error('Error fetching product attributes:', error)
    return {
      items: [],
      total_count: 0,
      search_criteria: {},
    } as unknown as MagentoResultType<ProductType>
  }
}
